# Stock Market MIS Dashboard

**Author:** Sahil Barot  
**Tools:** Python · pandas · yfinance · matplotlib · seaborn · openpyxl  
**Type:** Financial Data Analysis · MIS Reporting · Portfolio Project

---

## Objective

Build a complete MIS (Management Information System) dashboard for top 10 Nifty stocks — tracking price movement, volume anomalies, 52-week range, and return correlations. This mirrors real-world financial reporting done in fund operations and capital markets analytics teams.

---

## Project Structure

```
Stock_Market_Analysis/
├── data/
│   ├── raw/          # Raw downloaded CSVs (one per stock)
│   └── processed/    # Cleaned CSVs + charts + Excel dashboard
├── notebooks/
│   ├── 01_data_download.ipynb
│   ├── 02_data_cleaning.ipynb
│   ├── 03_eda_analysis.ipynb
│   └── 04_visualization.ipynb
├── src/
│   └── download_data.py
├── requirements.txt
└── README.md
```

---

## Key Features

- Downloads 1 year of live stock data using yfinance (no manual downloads)
- Calculates daily, weekly, and monthly % price change for each stock
- Tracks 52-week high/low and volume metrics
- Generates 5 professional charts:
  - Monthly % price change (green/red bar chart)
  - Normalized price trend comparison
  - Average vs today volume
  - 52-week high vs low
  - Stock return correlation heatmap
- Exports complete MIS report to Excel with multiple sheets

---

## Key Findings

- Top monthly gainer and loser identified from real-time data
- Volume spikes flagged where today's volume exceeds 2x average
- Correlation matrix shows which stocks move together — useful for portfolio diversification analysis
- Full MIS summary table exported to Excel for management reporting

---

## How to Run

```bash
# Install dependencies
pip install -r requirements.txt

# Run notebooks in order
# 01 → 02 → 03 → 04
# Or run src/download_data.py to refresh data
python src/download_data.py
```

---

## Business Relevance

This project directly mirrors the daily MIS and reporting workflow in financial services companies — including IFSC/GIFT City operations teams, fund administrators, and capital markets back-office roles where analysts track equity performance, flag anomalies, and produce management reports.

"""
download_data.py
Reusable script to download stock data using yfinance.
Author: Sahil Barot
"""

import yfinance as yf
import pandas as pd
import os

STOCKS = {
    'Reliance':   'RELIANCE.NS',
    'TCS':        'TCS.NS',
    'HDFC_Bank':  'HDFCBANK.NS',
    'Infosys':    'INFY.NS',
    'ICICI_Bank': 'ICICIBANK.NS',
    'Wipro':      'WIPRO.NS',
    'SBI':        'SBIN.NS',
    'Bajaj_Fin':  'BAJFINANCE.NS',
    'HUL':        'HINDUNILVR.NS',
    'Maruti':     'MARUTI.NS'
}

def download_all(period='1y', interval='1d', save_path='../data/raw/'):
    os.makedirs(save_path, exist_ok=True)
    data = {}
    for name, ticker in STOCKS.items():
        df = yf.download(ticker, period=period, interval=interval, progress=False)
        df.columns = [col[0] if isinstance(col, tuple) else col for col in df.columns]
        df.to_csv(f'{save_path}{name}_raw.csv')
        data[name] = df
        print(f'Downloaded {name} — {len(df)} rows')
    return data

if __name__ == '__main__':
    download_all()
